import plotly.plotly as py
import plotly.graph_objs as go
import plotly.figure_factory as FF

# Create random data with numpy
import numpy as np
import pandas as pd
df = pd.read_csv('naturalidade_quimica.csv')

#sample_data_table = FF.create_table(df.head())
bar1 = go.Bar(
                    x=df['estado'], y=df['mas'] # Additional options
                   )
bar2 = go.Bar(
                    x=df['estado'], y=df['fem']# Additional options
                   )
layout = go.Layout(title='Simple Plot from csv data',
                   plot_bgcolor='rgb(230, 230,230)')
fig = go.Figure(data=[bar1,bar2], layout=layout)
py.plot(fig, filename='Naturalidade')