import plotly.plotly as py
import plotly.graph_objs as go
import plotly.figure_factory as FF

# Create random data with numpy
import numpy as np
import pandas as pd
df = pd.read_csv('nac_intercambio.csv')

#sample_data_table = FF.create_table(df.head())
bar1 = go.Bar(
                    x=df['nome_pais'], y=df['total'] # Additional options

                   )
layout = go.Layout(title='Naturalidade - Intercambistas',
                   plot_bgcolor='rgb(230, 230,230)')
fig = go.Figure(data=[bar1], layout=layout)
py.plot(fig, filename='NaturalidadeInter')