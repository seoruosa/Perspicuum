import plotly.plotly as py
import plotly.graph_objs as go
import plotly.figure_factory as FF

# Create random data with numpy
import numpy as np
import pandas as pd
df = pd.read_csv('despesas_siafem_desc_menor.csv')

#sample_data_table = FF.create_table(df.head())
bar1 = go.Bar(
                    x=df['despesa'], y=df['pago'] # Additional options

                   )
layout = go.Layout(title='Despesas - SIAFEM (20 maiores)',
                   plot_bgcolor='rgb(230, 230,230)')
fig = go.Figure(data=[bar1], layout=layout)
py.plot(fig, filename='DespesasSIAFEM')